#!/bin/bash
# Advanced Agentic AI - macOS one-click environment setup
# Compatible with Apple Silicon and Intel Macs (provided macOS and wheels are supported).
# Installs Python 3.13 via Homebrew if necessary and creates ~/Desktop/Advanced Agentic AI/venv.
# Uses official Homebrew installer only after user confirmation.

set -Eeuo pipefail
unset PYTHONHOME PYTHONPATH PYTHONSTARTUP

APP_NAME="Advanced Agentic AI"
PYTHON_MINOR="3.13"
PROJECT_DIR="$HOME/Desktop/$APP_NAME"
VENV_DIR="$PROJECT_DIR/venv"
REQ_FILE="$PROJECT_DIR/requirements.txt"

# Save installation logs on the Desktop even when setup fails early.
mkdir -p "$PROJECT_DIR"
LOG_FILE="$PROJECT_DIR/mac_setup.log"
exec > >(tee -a "$LOG_FILE") 2>&1

finish() {
    local result=$?
    trap - EXIT
    printf '\n============================================================\n'
    if [ "$result" -eq 0 ]; then
        printf '  SETUP COMPLETED SUCCESSFULLY\n'
        printf '  Project: %s\n' "$PROJECT_DIR"
        printf '  Python:  %s\n' "$VENV_DIR/bin/python"
        printf '  Run Jupyter using Launch_Jupyter.command in project folder\n'
    else
        printf '  SETUP DID NOT COMPLETE (exit code: %s)\n' "$result"
        printf '  Please review: %s\n' "$LOG_FILE"
    fi
    printf '============================================================\n'
    if [ -t 0 ]; then
        printf 'Press Return to close this window... '
        IFS= read -r _ || true
    fi
}
trap finish EXIT

fail() {
    printf '\nERROR: %s\n' "$*" >&2
    exit 1
}

section() {
    printf '\n============================================================\n'
    printf '%s\n' "$1"
    printf '============================================================\n'
}

section 'Advanced Agentic AI - Mac Environment Setup'
[ "$(uname -s)" = 'Darwin' ] || fail 'This installer is for macOS only.'
printf 'Mac architecture: %s\n' "$(uname -m)"
printf 'macOS version: %s\n' "$(sw_vers -productVersion)"
printf 'Python target: %s\n' "$PYTHON_MINOR"
printf 'Project folder: %s\n' "$PROJECT_DIR"

# Find the requested Python interpreter; never use Apple's system Python by accident.
python_works() {
    local candidate="$1"
    "$candidate" -c 'import sys, ssl, encodings, venv; assert sys.version_info[:2] == (3, 13)' >/dev/null 2>&1
}

find_python() {
    local candidate
    PYTHON_BIN=''
    for candidate in \
        /opt/homebrew/bin/python3.13 \
        /usr/local/bin/python3.13 \
        /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
        /opt/local/bin/python3.13; do
        if [ -x "$candidate" ] && python_works "$candidate"; then
            PYTHON_BIN="$candidate"
            return 0
        fi
    done
    if command -v python3.13 >/dev/null 2>&1; then
        candidate="$(command -v python3.13)"
        if python_works "$candidate"; then
            PYTHON_BIN="$candidate"
            return 0
        fi
    fi
    return 1
}

find_brew() {
    BREW_BIN=''
    local candidate
    for candidate in /opt/homebrew/bin/brew /usr/local/bin/brew; do
        if [ -x "$candidate" ]; then
            BREW_BIN="$candidate"
            return 0
        fi
    done
    if command -v brew >/dev/null 2>&1; then
        BREW_BIN="$(command -v brew)"
        return 0
    fi
    return 1
}

section '1. Checking Python 3.13'
if find_python; then
    printf 'Using existing Python: %s\n' "$PYTHON_BIN"
else
    printf 'Python 3.13 is not installed or cannot be used.\n'
    if ! find_brew; then
        printf '\nHomebrew is needed to install Python automatically.\n'
        printf 'Homebrew source: https://brew.sh\n'
        printf 'It may request your macOS administrator password.\n'
        if [ ! -t 0 ]; then
            fail 'No interactive Terminal. Install Homebrew and Python 3.13 manually, then rerun.'
        fi
        printf 'Install Homebrew from its official installer? [y/N]: '
        IFS= read -r answer
        case "$answer" in
            [yY]|[yY][eE][sS]) ;;
            *) fail 'Homebrew installation not authorized. Nothing was installed.' ;;
        esac
        brew_installer="$(mktemp "${TMPDIR:-/tmp}/homebrew-install.XXXXXX")"
        if ! curl --fail --location --silent --show-error \
          'https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh' \
          --output "$brew_installer"; then
            rm -f "$brew_installer"
            fail 'Could not download official Homebrew installer.'
        fi
        if ! /bin/bash "$brew_installer"; then
            rm -f "$brew_installer"
            fail 'Homebrew installation failed. Command Line Tools may be required (xcode-select --install).'
        fi
        rm -f "$brew_installer"
        find_brew || fail 'Homebrew installed, but could not locate brew.'
    fi
    section 'Installing Python 3.13 with Homebrew'
    printf 'Homebrew: %s\n' "$BREW_BIN"
    HOMEBREW_NO_ASK=1 "$BREW_BIN" install python@3.13 || fail 'Homebrew could not install Python 3.13.'
    find_python || fail 'Python 3.13 is still unavailable after Homebrew installation.'
fi
"$PYTHON_BIN" --version

section '2. Preparing the Advanced Agentic AI folder'
cd "$PROJECT_DIR" || fail 'Could not access project folder.'
# Avoid overwriting any requirements.txt the learner has customized on a re-run.
if [ ! -f "$REQ_FILE" ]; then
    cat > "$REQ_FILE" <<'REQUIREMENTS_EOF'
# ============================================================
# Advanced Agentic AI: Production Engineering
# Walmart Global Tech Academy | requirements.txt
#
# Covers: Days 1-5 (Notebooks IN01-IN17 + ARB Capstone)
# Python: 3.13 (Mac setup matches Windows BAT)
# ============================================================

# Core OpenAI SDK
openai>=1.30.0
tiktoken>=0.7.0

# Environment variables
python-dotenv>=1.0.0

# LangChain ecosystem
langchain>=0.2.16
langchain-core>=0.2.38
langchain-openai>=0.1.22
langchain-community>=0.2.16

# LangGraph
langgraph>=0.2.0

# Vector stores
chromadb>=0.5.0
faiss-cpu>=1.7.4
pinecone>=6.0.0

# Fine-tuning frameworks
transformers>=4.40.0
peft>=0.11.0
accelerate>=0.30.0
datasets>=2.20.0

# Evaluation metrics
rouge-score>=0.1.2
nltk>=3.8.1
scikit-learn>=1.4.0

# Observability
langfuse>=2.0.0

# Utilities
pydantic>=2.7.0
numpy>=1.26.0
rich>=13.7.0
requests>=2.31.0
pypdf

# Network & Infrastructure Engineering
mcp>=1.0.0
pandas>=2.2.0
PyYAML>=6.0.1

# Jupyter environment
jupyter>=1.0.0
ipykernel>=6.29.0
notebook>=7.2.0
REQUIREMENTS_EOF
    printf 'Created %s\n' "$REQ_FILE"
else
    printf 'Using existing requirements.txt; keeping your previous changes.\n'
fi

section '3. Creating virtual environment'
if [ -e "$VENV_DIR" ] && [ ! -x "$VENV_DIR/bin/python" ]; then
    fail 'An existing venv folder is incomplete. Rename it manually and rerun; no files were deleted.'
fi
if [ -x "$VENV_DIR/bin/python" ]; then
    if ! "$VENV_DIR/bin/python" -c 'import sys; assert sys.version_info[:2] == (3, 13)' >/dev/null 2>&1; then
        fail 'An existing venv uses a different/broken Python. Rename it and rerun; no files were deleted.'
    fi
    printf 'Existing Python 3.13 virtual environment will be reused.\n'
else
    "$PYTHON_BIN" -m venv "$VENV_DIR" || fail 'Unable to create the virtual environment.'
fi

# Always call the venv interpreter explicitly, so Terminal shell state does not matter.
VENV_PY="$VENV_DIR/bin/python"
"$VENV_PY" --version
"$VENV_PY" -c 'import sys; print("Virtual environment:", sys.executable)'

section '4. Upgrading pip'
"$VENV_PY" -m pip install --upgrade pip || fail 'pip upgrade failed.'

section '5. Installing Agentic AI libraries'
"$VENV_PY" -m pip install --prefer-binary -r "$REQ_FILE" || fail 'Library installation failed. See mac_setup.log for exact error.'
"$VENV_PY" -m pip check || fail 'Installed packages have incompatible requirements.'

section '6. Verifying important libraries'
"$VENV_PY" - <<'PY_VERIFY'
import importlib
import sys
modules = {
    'OpenAI': 'openai',
    'LangChain': 'langchain',
    'LangGraph': 'langgraph',
    'ChromaDB': 'chromadb',
    'FAISS': 'faiss',
    'Transformers': 'transformers',
    'Pandas': 'pandas',
    'NumPy': 'numpy',
    'Jupyter': 'jupyter',
    'MCP': 'mcp',
    'PyPDF': 'pypdf',
    'Pinecone': 'pinecone',
}
failed = []
for name, module in modules.items():
    try:
        importlib.import_module(module)
        print(f'{name:16}: OK', flush=True)
    except Exception as exc:
        print(f'{name:16}: FAILED ({type(exc).__name__}: {exc})', flush=True)
        failed.append(name)
if failed:
    sys.exit('Verification failed for: ' + ', '.join(failed))
PY_VERIFY

section '7. Creating Jupyter launcher'
JUPYTER_LAUNCHER="$PROJECT_DIR/Launch_Jupyter.command"
if [ ! -e "$JUPYTER_LAUNCHER" ]; then
    cat > "$JUPYTER_LAUNCHER" <<'JUPYTER_EOF'
#!/bin/bash
cd "$HOME/Desktop/Advanced Agentic AI" || exit 1
"./venv/bin/python" -m notebook
result=$?
printf '\nJupyter exited (status %s). Press Return to close... ' "$result"
IFS= read -r _ || true
exit "$result"
JUPYTER_EOF
    chmod 755 "$JUPYTER_LAUNCHER"
    printf 'Created: %s\n' "$JUPYTER_LAUNCHER"
else
    printf 'Existing Jupyter launcher left unchanged.\n'
fi

printf '\nTo activate the environment in a new Terminal:\n'
printf '  cd "%s"\n' "$PROJECT_DIR"
printf '  source venv/bin/activate\n'
printf '\nSetup log: %s\n' "$LOG_FILE"
